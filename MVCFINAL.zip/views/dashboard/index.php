<?php
	require_once('views/system_header.php');
	require_once('views/dashboard/content_header.php');
?>

<!--CONTENT GOES HERE -->

<?php
	require_once('views/system_footer.php');
	require_once('views/dashboard/content_footer.php');
?>