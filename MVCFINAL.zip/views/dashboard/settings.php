<?php
	require_once('views/system_header.php');
	require_once('views/dashboard/content_header.php');
?>



<?php
	require_once('views/system_footer.php');
	require_once('views/dashboard/content_footer.php');
?>