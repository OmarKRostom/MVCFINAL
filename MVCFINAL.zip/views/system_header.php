<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?=$_SESSION['website_title'];?> dashboard</title>
    <script type="text/javascript" src="<?=$GLOBALS['LOCAL_ROOT'];?>/libs/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?=$GLOBALS['LOCAL_ROOT'];?>/libs/js/bootstrap.js"></script>
    <link rel="stylesheet" href="<?=$GLOBALS['LOCAL_ROOT'];?>/libs/css/bootstrap.css"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=$GLOBALS['LOCAL_ROOT'];?>/libs/css/main.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="<?=$GLOBALS['LOCAL_ROOT'];?>/libs/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?=$GLOBALS['LOCAL_ROOT'];?>/libs/dist/css/skins/skin-blue.min.css">
  </head>
  <body>
