<?php

class settings extends dashboard {
	function index() {
		$this->loadView('dashboard/settings.php');
	}
}


?>