<?php

class error extends controller
{
  function index() {
  	$this->loadView('dashboard/home','error');
  }
}

?>
