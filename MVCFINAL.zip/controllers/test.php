<?php

class test extends controller
{
  function index() {
  	require('views/home/index.php');
  }
}

?>
