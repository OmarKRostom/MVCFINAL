<?php

class home extends dashboard
{
  function index() {
  	$this->loadView('dashboard/home','view');
  }
}

?>
