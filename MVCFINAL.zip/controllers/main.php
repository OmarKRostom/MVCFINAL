<?php

class main extends controller
{
  function index() {
  	$this->loadView('home','index');
  }
}

?>
